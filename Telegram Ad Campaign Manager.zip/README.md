
  # Telegram Ad Campaign Manager

  This is a code bundle for Telegram Ad Campaign Manager. The original project is available at https://www.figma.com/design/iB4JA0FAIKbtH5vJ7WUbzx/Telegram-Ad-Campaign-Manager.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  