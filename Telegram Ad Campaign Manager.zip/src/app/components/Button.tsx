import { ReactNode } from 'react';

interface ButtonProps {
  children: ReactNode;
  variant?: 'primary' | 'secondary';
  onClick?: () => void;
}

export function Button({ children, variant = 'primary', onClick }: ButtonProps) {
  if (variant === 'primary') {
    return (
      <button
        onClick={onClick}
        className="px-8 py-4 bg-black text-white font-semibold hover:bg-white hover:text-black border-2 border-black transition-colors duration-300"
      >
        {children}
      </button>
    );
  }

  return (
    <button
      onClick={onClick}
      className="px-8 py-4 bg-white text-black font-semibold border-2 border-black hover:bg-black hover:text-white transition-colors duration-300"
    >
      {children}
    </button>
  );
}
