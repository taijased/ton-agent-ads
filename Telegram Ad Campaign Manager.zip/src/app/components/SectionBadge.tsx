interface SectionBadgeProps {
  children: string;
  variant?: 'light' | 'dark';
}

export function SectionBadge({ children, variant = 'light' }: SectionBadgeProps) {
  if (variant === 'dark') {
    return (
      <div className="inline-block relative mb-8">
        <div className="px-5 py-2 bg-white text-black font-bold tracking-wider text-sm uppercase shadow-[4px_4px_0px_0px_rgba(255,255,255,0.3)]">
          {children}
        </div>
      </div>
    );
  }

  return (
    <div className="inline-block relative mb-8">
      <div className="px-5 py-2 bg-black text-white font-bold tracking-wider text-sm uppercase shadow-[4px_4px_0px_0px_rgba(0,0,0,0.3)]">
        {children}
      </div>
    </div>
  );
}
