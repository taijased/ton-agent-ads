import { LucideIcon } from 'lucide-react';
import { motion } from 'motion/react';

interface StepCardProps {
  number: string;
  icon: LucideIcon;
  title: string;
  description: string;
  index: number;
}

export function StepCard({ number, icon: Icon, title, description, index }: StepCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.15 }}
      className="relative"
    >
      <div className="border-2 border-black p-8 bg-white hover:bg-black hover:text-white transition-colors duration-300 group">
        <div className="absolute -top-4 -left-4 w-12 h-12 bg-black text-white flex items-center justify-center text-xl font-bold group-hover:bg-white group-hover:text-black transition-colors duration-300">
          {number}
        </div>
        <Icon className="w-10 h-10 mb-4 transition-transform duration-300 group-hover:scale-110" />
        <h3 className="text-2xl font-semibold mb-3">{title}</h3>
        <p className="opacity-70">{description}</p>
      </div>
    </motion.div>
  );
}