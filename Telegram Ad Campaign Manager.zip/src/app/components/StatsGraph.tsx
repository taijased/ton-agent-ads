import { motion } from 'motion/react';

export function StatsGraph() {
  const bars = [
    { height: 40, label: 'Manual' },
    { height: 35, label: 'Search' },
    { height: 50, label: 'Negotiate' },
    { height: 30, label: 'Track' },
    { height: 45, label: 'Verify' },
  ];

  return (
    <div className="max-w-md mx-auto mb-16">
      <div className="border-2 border-black p-8 bg-white">
        <div className="text-sm font-bold mb-6 text-center">TIME SPENT ON MANUAL TASKS</div>
        <div className="flex items-end justify-between gap-3 h-32 mb-4">
          {bars.map((bar, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-2">
              <motion.div
                initial={{ height: 0 }}
                whileInView={{ height: `${bar.height}%` }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: i * 0.1 }}
                className="w-full bg-black"
              />
              <div className="text-xs font-bold">{bar.label}</div>
            </div>
          ))}
        </div>
        <div className="border-t-2 border-black pt-3 text-center">
          <div className="text-xs opacity-60">Hours wasted per campaign</div>
        </div>
      </div>
    </div>
  );
}
