import { motion } from 'motion/react';
import { BarChart3, TrendingUp, Users, MessageSquare } from 'lucide-react';

export function DashboardMockup() {
  return (
    <div className="relative">
      <div className="border-2 border-black p-6 bg-white">
        {/* Dashboard Header */}
        <div className="border-b-2 border-black pb-4 mb-4">
          <div className="flex items-center justify-between">
            <div className="text-xs font-bold">ACTIVE CAMPAIGNS</div>
            <div className="text-xs px-2 py-1 bg-black text-white">LIVE</div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="border-2 border-black p-3"
          >
            <TrendingUp className="w-5 h-5 mb-1" />
            <div className="text-xs opacity-60">Views</div>
            <div className="text-lg font-bold">2.4M</div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            className="border-2 border-black p-3"
          >
            <Users className="w-5 h-5 mb-1" />
            <div className="text-xs opacity-60">Subscribers</div>
            <div className="text-lg font-bold">+8.2K</div>
          </motion.div>
        </div>

        {/* Chart Visualization */}
        <div className="border-2 border-black p-4 bg-black/5 mb-4">
          <div className="flex items-end justify-between h-24 gap-1">
            {[40, 65, 45, 80, 55, 90, 70].map((height, i) => (
              <motion.div
                key={i}
                initial={{ height: 0 }}
                animate={{ height: `${height}%` }}
                transition={{ delay: 0.4 + i * 0.1, duration: 0.5 }}
                className="flex-1 bg-black"
              />
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="space-y-2">
          <div className="text-xs font-bold mb-2">RECENT ACTIVITY</div>
          {[1, 2, 3].map((i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.8 + i * 0.1 }}
              className="flex items-center gap-2 text-xs border border-black/20 p-2"
            >
              <MessageSquare className="w-3 h-3" />
              <span className="flex-1 opacity-60">Channel #{i} posted</span>
              <span className="font-bold">{i}h ago</span>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Floating Cards */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="absolute -top-6 -right-6 bg-white border-2 border-black px-4 py-3 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]"
      >
        <div className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5" />
          <span className="font-semibold">+234% ROI</span>
        </div>
      </motion.div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="absolute -bottom-6 -left-6 bg-black text-white border-2 border-black px-4 py-3 shadow-[8px_8px_0px_0px_rgba(0,0,0,0.3)]"
      >
        <div className="flex items-center gap-2">
          <BarChart3 className="w-5 h-5" />
          <span className="font-semibold">AI Powered</span>
        </div>
      </motion.div>
    </div>
  );
}
