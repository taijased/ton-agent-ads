import { LucideIcon } from 'lucide-react';
import { motion } from 'motion/react';

interface ProblemCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  index: number;
}

export function ProblemCard({ icon: Icon, title, description, index }: ProblemCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="border-2 border-black p-6 hover:bg-black hover:text-white transition-colors duration-300 group"
    >
      <Icon className="w-8 h-8 mb-4 transition-transform duration-300 group-hover:scale-110" />
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-sm opacity-70">{description}</p>
    </motion.div>
  );
}