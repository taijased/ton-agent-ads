import { motion } from 'motion/react';
import {
  Search,
  MessageSquare,
  FileX,
  ShieldAlert,
  BarChart3,
  Sparkles,
  Bot,
  Coins,
  CheckCircle,
  TrendingUp,
  Target,
  Zap,
  Globe,
  Clock,
  DollarSign,
  PieChart,
} from 'lucide-react';
import { ProblemCard } from './components/ProblemCard';
import { SolutionCard } from './components/SolutionCard';
import { StepCard } from './components/StepCard';
import { BenefitCard } from './components/BenefitCard';
import { Button } from './components/Button';
import { DashboardMockup } from './components/DashboardMockup';
import { SectionBadge } from './components/SectionBadge';
import { StatsGraph } from './components/StatsGraph';
import { FlowArrow } from './components/FlowArrow';
import { BenefitsPattern } from './components/BenefitsPattern';
import { CircularProgress } from './components/CircularProgress';

export default function App() {
  return (
    <div className="min-h-screen bg-white text-black">
      {/* Hero Section */}
      <section className="border-b-2 border-black">
        <div className="max-w-7xl mx-auto px-6 py-20 lg:py-32">
          <div className="grid lg:grid-cols-[1.3fr,0.7fr] gap-12 lg:gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <SectionBadge>Hero</SectionBadge>
              <h1 className="text-5xl lg:text-6xl xl:text-7xl font-bold mb-6 leading-tight">
                More awareness.<br />
                More traffic.<br />
                More subscribers.<br />
                <span className="opacity-60">Less manual work.</span>
              </h1>
              <p className="text-xl lg:text-2xl mb-8 opacity-80 max-w-xl">
                Run Telegram ad campaigns through an AI agent that finds channels, negotiates with admins, pays in TON, and tracks results.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button variant="primary">Start campaign</Button>
                <Button variant="secondary">Watch demo</Button>
              </div>
            </motion.div>
            
            {/* Dashboard Mockup */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <DashboardMockup />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="border-b-2 border-black bg-white">
        <div className="max-w-7xl mx-auto px-6 py-20 lg:py-28">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <SectionBadge>Problem</SectionBadge>
            <h2 className="text-4xl lg:text-5xl xl:text-6xl font-bold mb-4">
              Telegram ad buying is still manual
            </h2>
            <p className="text-xl lg:text-2xl opacity-70 mb-12 max-w-3xl">
              Finding channels, negotiating with admins, tracking deals, verifying posts, and collecting analytics happens across chats, spreadsheets, and notes.
            </p>
          </motion.div>
          
          <StatsGraph />
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ProblemCard
              icon={Search}
              title="Manual channel search"
              description="You spend hours looking for the right channels."
              index={0}
            />
            <ProblemCard
              icon={MessageSquare}
              title="Endless admin chats"
              description="Every deal requires back-and-forth messages."
              index={1}
            />
            <ProblemCard
              icon={FileX}
              title="No deal tracking"
              description="Campaign details get lost in conversations."
              index={2}
            />
            <ProblemCard
              icon={ShieldAlert}
              title="Hard to verify posts"
              description="You never know if everything was published correctly."
              index={3}
            />
            <ProblemCard
              icon={BarChart3}
              title="Scattered analytics"
              description="Results live in screenshots, links, and tables."
              index={4}
            />
          </div>
        </div>
      </section>

      {/* Solution Section */}
      <section className="border-b-2 border-black bg-black text-white">
        <div className="max-w-7xl mx-auto px-6 py-20 lg:py-28">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <SectionBadge variant="dark">Solution</SectionBadge>
            <h2 className="text-4xl lg:text-5xl xl:text-6xl font-bold mb-4">
              One agent runs the whole campaign
            </h2>
            <p className="text-xl lg:text-2xl opacity-70 mb-12 max-w-3xl">
              Create a campaign once. The agent finds channels, negotiates deals, sends payments, verifies posts, and tracks results.
            </p>
          </motion.div>
          
          {/* Circular Progress Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16 max-w-4xl mx-auto">
            <CircularProgress percentage={95} label="Automation" />
            <CircularProgress percentage={80} label="Time Saved" />
            <CircularProgress percentage={100} label="Accuracy" />
            <CircularProgress percentage={90} label="ROI Boost" />
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <SolutionCard
              icon={Sparkles}
              title="Channel recommendation"
              description="The agent finds the best channels for your campaign."
              index={0}
            />
            <SolutionCard
              icon={Bot}
              title="Negotiation automation"
              description="No more back-and-forth with admins."
              index={1}
            />
            <SolutionCard
              icon={Coins}
              title="TON payments"
              description="Move from deal to payment instantly."
              index={2}
            />
            <SolutionCard
              icon={CheckCircle}
              title="Post verification"
              description="Know when your ad is published."
              index={3}
            />
            <SolutionCard
              icon={BarChart3}
              title="Campaign analytics"
              description="Track results in one place."
              index={4}
            />
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="border-b-2 border-black bg-white">
        <div className="max-w-7xl mx-auto px-6 py-20 lg:py-28">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <SectionBadge>How it works</SectionBadge>
            <h2 className="text-4xl lg:text-5xl xl:text-6xl font-bold mb-16">
              From idea to results in one flow
            </h2>
          </motion.div>
          
          {/* Flow with Arrows */}
          <div className="grid lg:grid-cols-[1fr,auto,1fr,auto,1fr] gap-8 lg:gap-4 items-start max-w-6xl mx-auto mb-12">
            <StepCard
              number="01"
              icon={Target}
              title="Create campaign"
              description="Set your goal, budget, and campaign details."
              index={0}
            />
            <FlowArrow />
            <StepCard
              number="02"
              icon={Sparkles}
              title="Channel recommendation"
              description="The agent finds Telegram channels that match your campaign."
              index={1}
            />
            <FlowArrow />
            <StepCard
              number="03"
              icon={Bot}
              title="Negotiation"
              description="The agent talks to admins and agrees on the price."
              index={2}
            />
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 lg:gap-12 max-w-4xl mx-auto">
            <StepCard
              number="04"
              icon={Coins}
              title="Approval and payment"
              description="Review the deal and confirm the purchase in one click."
              index={3}
            />
            <StepCard
              number="05"
              icon={TrendingUp}
              title="Results and analytics"
              description="Track publications, views, and subscribers in real time."
              index={4}
            />
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="border-b-2 border-black bg-white relative overflow-hidden">
        <BenefitsPattern />
        <div className="max-w-7xl mx-auto px-6 py-20 lg:py-28 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <SectionBadge>Benefits</SectionBadge>
            <h2 className="text-4xl lg:text-5xl xl:text-6xl font-bold mb-16">
              Built for faster campaign growth
            </h2>
          </motion.div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <BenefitCard
              icon={Clock}
              title="Less manual work"
              description="Stop searching channels and negotiating in chats."
              index={0}
            />
            <BenefitCard
              icon={Target}
              title="Better channel matching"
              description="Find the right Telegram channels faster."
              index={1}
            />
            <BenefitCard
              icon={Globe}
              title="Transparent deals"
              description="See price, status, and history in one place."
              index={2}
            />
            <BenefitCard
              icon={Zap}
              title="Faster campaign launch"
              description="Go from idea to post in minutes."
              index={3}
            />
            <BenefitCard
              icon={PieChart}
              title="All analytics in one place"
              description="Track views, clicks, and subscribers easily."
              index={4}
            />
            <BenefitCard
              icon={DollarSign}
              title="Native TON payments"
              description="Move from deal to payment instantly."
              index={5}
            />
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="bg-black text-white">
        <div className="max-w-4xl mx-auto px-6 py-20 lg:py-32 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <SectionBadge variant="dark">Final CTA</SectionBadge>
            <h2 className="text-4xl lg:text-6xl xl:text-7xl font-bold mb-6">
              Run your next Telegram campaign with an agent
            </h2>
            <p className="text-xl lg:text-2xl opacity-70 mb-10 max-w-2xl mx-auto">
              From channel discovery to payment and analytics — all in one flow.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <button className="px-8 py-4 bg-white text-black font-semibold hover:bg-black hover:text-white border-2 border-white transition-colors duration-300">
                Start campaign
              </button>
              <button className="px-8 py-4 bg-black text-white font-semibold border-2 border-white hover:bg-white hover:text-black transition-colors duration-300">
                Watch demo
              </button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}